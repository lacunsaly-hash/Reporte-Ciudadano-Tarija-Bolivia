/* Reporte Ciudadano — interacciones y almacenamiento local */
(() => {
  "use strict";
  const STORAGE_REPORTS = "reporteCiudadano.reports.v1";
  const STORAGE_PROFILE = "reporteCiudadano.profile.v1";
  const WHATSAPP_NUMBER = "59172981122"; // Bolivia (+591) + 72981122
  const STATUSES = ["Recibido", "En revisión", "En proceso", "Atendido", "Resuelto"];
  const CATEGORIES = [
    {name:"Calles y baches",icon:"▰",desc:"Baches, pavimento dañado o aceras en mal estado."},
    {name:"Basura y limpieza",icon:"♻",desc:"Basura acumulada, puntos sucios o falta de limpieza."},
    {name:"Alumbrado público",icon:"☼",desc:"Luminarias apagadas o dañadas en calles y plazas."},
    {name:"Fugas de agua",icon:"♧",desc:"Fugas visibles o pérdida de agua en espacios públicos."},
    {name:"Semáforos y señalización",icon:"🚦",desc:"Semáforos dañados o señales faltantes."},
    {name:"Espacios públicos",icon:"♧",desc:"Plazas, parques, juegos o mobiliario deteriorado."},
    {name:"Alcantarillado",icon:"≋",desc:"Desagües obstruidos u otros problemas de alcantarillado."},
    {name:"Otros problemas urbanos",icon:"＋",desc:"Otro problema que necesita atención en tu zona."}
  ];
  const ACTIONS = [
    {title:"Reporta lo que ves",icon:"⌕",short:"Informa sobre problemas de tu entorno.",detail:"Describe el problema con palabras claras e indica una ubicación que otras personas puedan reconocer. Evita publicar datos privados de terceros."},
    {title:"Aporta evidencia",icon:"▧",short:"Una foto puede ayudar a entender la situación.",detail:"Si es seguro hacerlo, toma una fotografía que muestre el problema. La foto queda seleccionada en el formulario, pero no se adjunta automáticamente al mensaje de WhatsApp."},
    {title:"Participa en comunidad",icon:"♧",short:"Comparte información útil y cuida los espacios.",detail:"La participación respetuosa ayuda a identificar necesidades comunes. No te expongas a riesgos para obtener información o tomar fotografías."},
    {title:"Haz seguimiento",icon:"↗",short:"Conserva tu código y revisa el estado.",detail:"Usa el código de seguimiento para encontrar tu reporte en este navegador. Los cambios de estado disponibles aquí son demostrativos, no actualizaciones oficiales."}
  ];
  const $ = (id) => document.getElementById(id);
  let toastTimer;
  let currentReportCode = null;

  function readStorage(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
      console.warn("No se pudo leer el almacenamiento local.", error);
      return fallback;
    }
  }
  function writeStorage(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (error) { console.error("No se pudo guardar en el almacenamiento local.", error); showToast("No se pudo guardar. Comprueba el espacio disponible o la configuración del navegador."); return false; }
  }
  function getReports() {
    const value = readStorage(STORAGE_REPORTS, []);
    return Array.isArray(value) ? value : [];
  }
  function saveReports(reports) { return writeStorage(STORAGE_REPORTS, reports); }
  function getProfile() {
    const value = readStorage(STORAGE_PROFILE, {});
    return value && typeof value === "object" ? value : {};
  }
  function showToast(message) {
    const toast = $("toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
  }
  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  }
  function formatDate(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "Fecha no disponible";
    return new Intl.DateTimeFormat("es-BO", {dateStyle:"medium", timeStyle:"short"}).format(date);
  }
  function createCode(reports) {
    const date = new Date();
    const ymd = `${date.getFullYear()}${String(date.getMonth()+1).padStart(2,"0")}${String(date.getDate()).padStart(2,"0")}`;
    let code;
    do {
      const suffix = Math.random().toString(36).slice(2,6).toUpperCase().padEnd(4,"X");
      code = `RC-${ymd}-${suffix}`;
    } while (reports.some(report => String(report.code).toUpperCase() === code));
    return code;
  }
  function whatsappURL(message) {
    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  }
  function openWhatsApp(url) {
    const opened = window.open(url, "_blank", "noopener,noreferrer");
    if (!opened) {
      const feedback = $("reportFeedback");
      if (feedback) {
        const link = document.createElement("a");
        link.href = url; link.target = "_blank"; link.rel = "noopener noreferrer";
        link.className = "btn"; link.textContent = "Abrir WhatsApp";
        feedback.append(" ", link);
      }
    }
  }

  function renderCategories() {
    const grid = $("problemGrid"), select = $("reportCategory");
    if (!grid || !select) return;
    CATEGORIES.forEach((cat, index) => {
      const button = document.createElement("button");
      button.type = "button"; button.className = "problem-card";
      const categoryPhotos = [
        "https://images.unsplash.com/photo-1519003722824-194d4455a60c?auto=format&fit=crop&w=700&q=80",
        "https://images.unsplash.com/photo-1605600659873-d808a13e4d9a?auto=format&fit=crop&w=700&q=80",
        "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=700&q=80",
        "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?auto=format&fit=crop&w=700&q=80",
        "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=700&q=80",
        "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=700&q=80",
        "https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=700&q=80",
        "https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=700&q=80"
      ];
      button.innerHTML = `<img class="problem-photo" src="${categoryPhotos[index]}" alt="Fotografía ilustrativa: ${escapeHTML(cat.name)}" loading="lazy"><span class="problem-icon" aria-hidden="true">${cat.icon}</span><h3>${escapeHTML(cat.name)}</h3><p>${escapeHTML(cat.desc)}</p><span class="card-cta">Crear reporte →</span>`;
      button.addEventListener("click", () => openReport(cat.name));
      grid.appendChild(button);
      const option = document.createElement("option");
      option.value = cat.name; option.textContent = cat.name; select.appendChild(option);
    });
  }
  function renderActions() {
    const grid = $("actionGrid");
    if (!grid) return;
    ACTIONS.forEach((action, index) => {
      const button = document.createElement("button");
      button.type = "button"; button.className = `action-card${index===0?" active":""}`;
      button.setAttribute("aria-pressed", String(index===0));
      button.innerHTML = `<span class="problem-icon" aria-hidden="true">${action.icon}</span><h3>${escapeHTML(action.title)}</h3><p>${escapeHTML(action.short)}</p>`;
      button.addEventListener("click", () => selectAction(index));
      grid.appendChild(button);
    });
    selectAction(0);
  }
  function selectAction(index) {
    const action = ACTIONS[index], grid = $("actionGrid"), detail = $("actionDetail");
    if (!action || !grid || !detail) return;
    [...grid.children].forEach((button, i) => {
      button.classList.toggle("active", i === index);
      button.setAttribute("aria-pressed", String(i === index));
    });
    detail.innerHTML = `<div class="detail-illustration" aria-hidden="true">${action.icon}</div><div><h3>${escapeHTML(action.title)}</h3><p>${escapeHTML(action.detail)}</p><button type="button" class="btn" data-open-report>Crear un reporte</button></div>`;
    detail.querySelector("[data-open-report]")?.addEventListener("click", () => openReport());
  }

  const dialog = $("reportDialog");
  function openReport(category = "") {
    if (!dialog) return;
    const profile = getProfile();
    const form = $("reportForm");
    if (form) {
      form.reset();
      $("reportName").value = profile.name || "";
      $("reportPhone").value = profile.phone || "";
      $("reportCategory").value = category || "";
      $("registrationDate").textContent = formatDate(new Date());
      $("reportFeedback").innerHTML = "";
      $("locationMessage").textContent = "";
      $("photoName").textContent = "No se enviará automáticamente por WhatsApp; podrás adjuntarla manualmente.";
      document.querySelectorAll(".error").forEach(el => el.textContent = "");
    }
    if (typeof dialog.showModal === "function") {
      if (!dialog.open) dialog.showModal();
      document.body.classList.add("dialog-open");
      setTimeout(() => $("reportName")?.focus(), 50);
    } else {
      showToast("Tu navegador no admite este formulario emergente. Prueba con una versión reciente de Chrome.");
    }
  }
  function closeReport() {
    if (dialog?.open) dialog.close();
    document.body.classList.remove("dialog-open");
  }
  document.querySelectorAll("[data-open-report]").forEach(button => button.addEventListener("click", () => openReport()));
  $("closeDialog")?.addEventListener("click", closeReport);
  dialog?.addEventListener("click", event => { if (event.target === dialog) closeReport(); });
  dialog?.addEventListener("close", () => document.body.classList.remove("dialog-open"));
  document.addEventListener("keydown", event => { if (event.key === "Escape") document.body.classList.remove("dialog-open"); });

  $("reportPhoto")?.addEventListener("change", event => {
    const file = event.target.files?.[0];
    $("photoName").textContent = file ? `Archivo seleccionado: ${file.name}. La foto no se adjunta automáticamente a WhatsApp.` : "No se enviará automáticamente por WhatsApp; podrás adjuntarla manualmente.";
  });
  $("useLocation")?.addEventListener("click", () => {
    const message = $("locationMessage");
    if (!navigator.geolocation) { message.textContent = "Este navegador no ofrece geolocalización. Escribe la ubicación manualmente."; return; }
    message.textContent = "Solicitando permiso de ubicación…";
    navigator.geolocation.getCurrentPosition(position => {
      const {latitude, longitude} = position.coords;
      $("reportLocation").value = `Coordenadas aproximadas: ${latitude.toFixed(5)}, ${longitude.toFixed(5)}`;
      message.textContent = "Ubicación obtenida. Puedes añadir una calle o referencia para facilitar su identificación.";
    }, () => {
      message.textContent = "No se pudo obtener la ubicación o no se concedió permiso. Puedes escribirla manualmente.";
      $("reportLocation").focus();
    }, {enableHighAccuracy:false, timeout:10000, maximumAge:60000});
  });

  function findDuplicate(category, location) {
    const normalize = value => String(value || "").trim().toLocaleLowerCase("es");
    const target = normalize(location);
    return getReports().find(report => normalize(report.category) === normalize(category) &&
      (normalize(report.location) === target || (target.length > 5 && (normalize(report.location).includes(target) || target.includes(normalize(report.location))))));
  }
  function showSuccess(report, waUrl) {
    const feedback = $("reportFeedback");
    feedback.innerHTML = `<div class="success-panel"><h3>✓ ¡Gracias! Tu reporte fue confirmado</h3><p>El reporte quedó guardado en este navegador y su estado inicial es <strong>Recibido</strong>.</p><p>Tu código de seguimiento:</p><div class="success-code">${escapeHTML(report.code)}</div><p class="confirmation-note">Para que llegue al número ciudadano, pulsa “Enviar reporte al 72981122”. WhatsApp abrirá el mensaje preparado; por seguridad, debes pulsar Enviar dentro de WhatsApp. Este sitio no puede enviarlo en segundo plano sin un servidor conectado a la API oficial de WhatsApp Business.</p><p>La fotografía no se adjunta automáticamente; si hace falta, puedes agregarla dentro de WhatsApp.</p><div class="success-actions"><a class="btn" id="whatsAppFallback" href="${escapeHTML(waUrl)}" target="_blank" rel="noopener noreferrer">Enviar reporte al 72981122</a><button type="button" class="btn btn-outline" id="copyCode">Copiar código</button><button type="button" class="btn btn-outline" id="goTrack">Consultar seguimiento</button></div></div>`;
    $("copyCode")?.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(report.code); showToast("Código copiado."); }
      catch { const temp = document.createElement("textarea"); temp.value = report.code; document.body.appendChild(temp); temp.select(); const ok = document.execCommand("copy"); temp.remove(); showToast(ok ? "Código copiado." : `Copia este código: ${report.code}`); }
    });
    $("goTrack")?.addEventListener("click", () => {
      closeReport();
      $("trackingCode").value = report.code;
      renderTracking(report.code);
      document.querySelector("#seguimiento")?.scrollIntoView({behavior:"smooth"});
    });
  }
  $("reportForm")?.addEventListener("submit", event => {
    event.preventDefault();
    const submit = $("submitReport");
    if (submit.disabled) return;
    const fields = {
      name: $("reportName").value.trim(), phone: $("reportPhone").value.trim(),
      category: $("reportCategory").value, description: $("reportDescription").value.trim(),
      location: $("reportLocation").value.trim()
    };
    const errors = {
      name: fields.name ? "" : "Escribe tu nombre.",
      category: fields.category ? "" : "Selecciona un tipo de problema.",
      description: fields.description.length >= 10 ? "" : "Describe el problema con al menos 10 caracteres.",
      location: fields.location ? "" : "Escribe la ubicación o utiliza el botón de ubicación."
    };
    Object.entries(errors).forEach(([key, value]) => { const el = $(`${key}Error`); if (el) el.textContent = value; });
    if (!fields.name || !fields.category || fields.description.length < 10 || !fields.location) {
      $("reportForm").reportValidity(); return;
    }
    const duplicate = findDuplicate(fields.category, fields.location);
    if (duplicate && !window.confirm(`Ya existe un reporte (${duplicate.code}) con una categoría y ubicación parecidas. ¿Deseas registrar otro de todas formas?`)) return;
    submit.disabled = true; submit.textContent = "Registrando…";
    try {
      const reports = getReports();
      const report = {...fields, code:createCode(reports), createdAt:new Date().toISOString(), status:0, photoName:$("reportPhoto").files?.[0]?.name || ""};
      reports.unshift(report);
      if (!saveReports(reports)) return;
      currentReportCode = report.code;
      renderMyReports();
      const message = `Nuevo reporte ciudadano.\nCódigo de seguimiento: ${report.code}\nNombre: ${fields.name}\nTipo de problema: ${fields.category}\nDescripción: ${fields.description}\nUbicación: ${fields.location}\nContacto: ${fields.phone || "No proporcionado"}`;
      const url = whatsappURL(message);
      showSuccess(report, url);
      showToast("Reporte confirmado y guardado en este navegador.");
    } finally {
      submit.disabled = false; submit.textContent = "Registrar reporte";
    }
  });

  function progressHTML(status) {
    return `<div class="progress-steps" aria-label="Progreso del reporte">${STATUSES.map((name,index)=>`<div class="progress-step ${index <= status ? "done" : ""}"><span class="progress-dot">${index <= status ? "✓" : index+1}</span><span>${name}</span></div>`).join("")}</div>`;
  }
  function renderTracking(code) {
    const output = $("trackingResult"), message = $("trackingMessage");
    if (!output) return;
    const cleaned = String(code || "").replace(/\s+/g,"").toLocaleUpperCase("es");
    if (message) message.textContent = "";
    if (!cleaned) { output.innerHTML = ""; if (message) message.textContent = "Escribe un código para consultar."; return; }
    const report = getReports().find(item => String(item.code || "").replace(/\s+/g,"").toLocaleUpperCase("es") === cleaned);
    if (!report) {
      output.innerHTML = `<div class="empty-state">No encontramos ese código en este navegador. Revisa que esté escrito correctamente o registra un nuevo reporte.<br><br><button class="btn btn-small" type="button" id="newReportFromSearch">Registrar un reporte</button></div>`;
      $("newReportFromSearch")?.addEventListener("click", () => openReport());
      return;
    }
    currentReportCode = report.code;
    const status = Math.min(Math.max(Number(report.status)||0,0),4);
    output.innerHTML = `<article class="result-card"><div class="result-top"><div><div class="result-code">${escapeHTML(report.code)}</div><strong>${escapeHTML(report.category)}</strong></div><span class="status-pill status-${status}">${escapeHTML(STATUSES[status])}</span></div><div class="result-meta"><div><strong>Ubicación</strong><span>${escapeHTML(report.location)}</span></div><div><strong>Fecha de creación</strong><span>${escapeHTML(formatDate(report.createdAt))}</span></div><div style="grid-column:1/-1"><strong>Descripción</strong><span>${escapeHTML(report.description)}</span></div></div>${progressHTML(status)}<div class="demo-row"><p><strong>Modo demostración:</strong> solo para la presentación, simula el cambio de estado. Es una simulación local, no una actualización institucional.</p><button class="btn btn-xs" type="button" id="advanceStatus" ${status>=4?"disabled":""}>${status>=4?"Último estado":"Avanzar estado →"}</button></div></article>`;
    $("advanceStatus")?.addEventListener("click", () => advanceStatus(report.code));
  }
  function advanceStatus(code) {
    const reports = getReports();
    const report = reports.find(item => item.code === code);
    if (!report) return;
    if ((Number(report.status)||0) >= 4) { showToast("El reporte ya está en el último estado demostrativo."); return; }
    report.status = (Number(report.status)||0) + 1;
    if (saveReports(reports)) {
      renderTracking(code); renderMyReports();
      showToast(`Simulación local: estado "${STATUSES[report.status]}".`);
    }
  }
  $("trackingForm")?.addEventListener("submit", event => { event.preventDefault(); renderTracking($("trackingCode").value); });
  function renderMyReports() {
    const target = $("myReports");
    if (!target) return;
    const reports = getReports();
    if (!reports.length) { target.innerHTML = `<div class="empty-state">Todavía no hay reportes guardados en este navegador.</div>`; return; }
    target.innerHTML = reports.slice(0,12).map(report => `<article class="mini-report"><strong>${escapeHTML(report.code)}</strong><p>${escapeHTML(report.category)}<br>${escapeHTML(report.location)}<br><span class="status-pill status-${Math.min(Number(report.status)||0,4)}">${escapeHTML(STATUSES[Math.min(Number(report.status)||0,4)])}</span></p><button class="btn btn-outline btn-xs" type="button" data-track="${escapeHTML(report.code)}">Consultar reporte</button></article>`).join("");
    target.querySelectorAll("[data-track]").forEach(button => button.addEventListener("click", () => {
      $("trackingCode").value = button.dataset.track;
      renderTracking(button.dataset.track);
      document.querySelector("#seguimiento")?.scrollIntoView({behavior:"smooth"});
    }));
  }

  $("profileForm")?.addEventListener("submit", event => {
    event.preventDefault();
    const profile = {name:$("profileName").value.trim(),phone:$("profilePhone").value.trim(),email:$("profileEmail").value.trim()};
    if (!profile.name) { $("profileName").focus(); return; }
    if (writeStorage(STORAGE_PROFILE, profile)) {
      $("profileMessage").textContent = "Perfil guardado en este navegador.";
      showToast("Perfil guardado.");
    }
  });
  $("deleteProfile")?.addEventListener("click", () => {
    if (!window.confirm("¿Quieres borrar el perfil guardado en este navegador?")) return;
    try { localStorage.removeItem(STORAGE_PROFILE); } catch (error) { console.warn(error); }
    $("profileForm")?.reset(); $("profileMessage").textContent = "Perfil local borrado.";
    showToast("Perfil borrado.");
  });
  function loadProfile() {
    const profile = getProfile();
    if ($("profileName")) $("profileName").value = profile.name || "";
    if ($("profilePhone")) $("profilePhone").value = profile.phone || "";
    if ($("profileEmail")) $("profileEmail").value = profile.email || "";
  }
  const menuToggle = $("menuToggle"), mainNav = $("mainNav");
  menuToggle?.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Cerrar menú" : "Abrir menú");
    menuToggle.textContent = isOpen ? "×" : "☰";
  });
  mainNav?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded","false");
    if (menuToggle) { menuToggle.setAttribute("aria-label","Abrir menú"); menuToggle.textContent="☰"; }
  }));
  $("year").textContent = new Date().getFullYear();
  renderCategories();
  renderActions();
  renderMyReports();
  loadProfile();
})();
