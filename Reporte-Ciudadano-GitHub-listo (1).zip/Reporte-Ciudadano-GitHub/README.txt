REPORTE CIUDADANO — versión lista para subir a GitHub Pages

Archivos necesarios (todos juntos en la raíz del repositorio):
- index.html
- style.css
- script.js
- tarija-inicio.png
- logo-lupa-ciudad.png

Para probar en tu computadora: abre index.html en Chrome. Si tu navegador bloquea algunas funciones al abrir un archivo local, publica los archivos en GitHub Pages.

Funciones:
- Los botones abren el formulario y las tarjetas permiten elegir una categoría.
- El formulario valida campos obligatorios, guarda reportes en el almacenamiento local del navegador y genera un código de seguimiento.
- El seguimiento consulta los reportes guardados en ese mismo navegador.
- WhatsApp prepara un mensaje al número 59172981122; el usuario todavía debe pulsar Enviar en WhatsApp.
- La foto se selecciona como referencia, pero no se carga a ningún servidor.

Importante: esta versión no envía reportes a una base institucional. Los datos quedan en el navegador/dispositivo donde se registran.
