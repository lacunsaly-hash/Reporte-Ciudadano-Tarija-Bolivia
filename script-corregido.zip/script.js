/* Reporte Ciudadano - JavaScript principal
   Funciones frontend: reportes/perfil en LocalStorage, validación, WhatsApp,
   seguimiento, geolocalización, menú móvil y panel interactivo.
   Importante: los estados son locales/demostrativos; no hay conexión institucional.
*/
(() => {
  'use strict';

  const STORAGE_REPORTS = 'reporteCiudadano_reportes_v1';
  const STORAGE_PROFILE = 'reporteCiudadano_perfil_v1';
  const WHATSAPP_NUMBER = '59172981122';
  const STATUS = ['Recibido', 'En revisión', 'En proceso', 'Atendido', 'Resuelto'];
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const first = (...selectors) => selectors.map(s => $(s)).find(Boolean) || null;

  function readJSON(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      console.warn('No se pudo leer LocalStorage:', error);
      return fallback;
    }
  }
  function saveJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      alert('No se pudieron guardar los datos en este navegador. Comprueba el espacio disponible o la configuración de privacidad.');
      console.error(error);
      return false;
    }
  }
  const getReports = () => readJSON(STORAGE_REPORTS, []);
  const getProfile = () => readJSON(STORAGE_PROFILE, { nombre: '', telefono: '', correo: '' });
  const clean = value => String(value ?? '').trim();
  const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, ch => ({
    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
  }[ch]));
  const todayISO = () => new Date().toISOString();
  const dateText = value => {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? 'Fecha no disponible' :
      date.toLocaleString('es-BO', { dateStyle: 'medium', timeStyle: 'short' });
  };
  function slug(value) {
    return clean(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  }
  function makeCode(existing) {
    let code;
    do {
      code = 'RC-' + new Date().getFullYear() + '-' +
        Math.random().toString(36).slice(2, 6).toUpperCase() +
        Math.random().toString(36).slice(2, 5).toUpperCase();
    } while (existing.some(report => report.codigo === code));
    return code;
  }
  function whatsappURL(message) {
    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  }
  function openWhatsApp(message) {
    const url = whatsappURL(message);
    // Abrir en la misma pestaña reduce los bloqueos de ventanas emergentes.
    window.location.href = url;
  }
  function showNotice(message, type = 'info') {
    let notice = $('#rc-notice');
    if (!notice) {
      notice = document.createElement('div');
      notice.id = 'rc-notice';
      notice.setAttribute('role', 'status');
      notice.setAttribute('aria-live', 'polite');
      Object.assign(notice.style, {
        position: 'fixed', right: '18px', bottom: '18px', zIndex: '99999',
        maxWidth: 'min(420px, calc(100vw - 36px))', padding: '14px 18px',
        borderRadius: '12px', boxShadow: '0 8px 28px #0002', fontSize: '15px',
        lineHeight: '1.45', background: '#fff', color: '#16324f',
        border: '1px solid #d7e3ee'
      });
      document.body.appendChild(notice);
    }
    notice.textContent = message;
    notice.style.borderLeft = `5px solid ${type === 'error' ? '#c83b43' : type === 'success' ? '#25845a' : '#2877c7'}`;
    if (notice._timer) clearTimeout(notice._timer);
    notice._timer = setTimeout(() => notice.remove(), 5500);
  }
  function scrollToElement(element) {
    if (!element) return;
    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (element.matches('input, select, textarea, button')) {
      setTimeout(() => element.focus({ preventScroll: true }), 350);
    }
  }
  function formField(form, names) {
    for (const name of names) {
      const found = form.querySelector(`[name="${name}"], #${CSS.escape(name)}`);
      if (found) return found;
    }
    return null;
  }
  function val(form, names) {
    const field = formField(form, names);
    return field ? clean(field.value) : '';
  }
  function setField(form, names, value) {
    const field = formField(form, names);
    if (field && value != null) {
      field.value = value;
      field.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  // Enlaza enlaces internos y botones de navegación sin depender de una biblioteca.
  function setupNavigation() {
    $$('a[href^="#"]').forEach(link => {
      link.addEventListener('click', event => {
        const target = $(link.getAttribute('href'));
        if (target) {
          event.preventDefault();
          scrollToElement(target);
          const menu = first('#nav-menu', '.nav-menu', '.navbar-menu', '[data-nav-menu]');
          if (menu) menu.classList.remove('is-open', 'open', 'active');
          const toggle = first('#menu-toggle', '.menu-toggle', '[data-menu-toggle]');
          if (toggle) toggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    const toggle = first('#menu-toggle', '.menu-toggle', '.hamburger', '[data-menu-toggle]');
    const menu = first('#nav-menu', '.nav-menu', '.navbar-menu', '[data-nav-menu]');
    if (toggle && menu) {
      toggle.setAttribute('aria-expanded', 'false');
      toggle.addEventListener('click', () => {
        const opened = menu.classList.toggle('is-open');
        menu.classList.toggle('open', opened);
        menu.classList.toggle('active', opened);
        toggle.setAttribute('aria-expanded', String(opened));
      });
    }

    $$('[data-open-report], .btn-reportar, #btn-reportar, #open-report-form').forEach(button => {
      button.addEventListener('click', () => openReportForm());
    });
    $$('[data-contact-whatsapp], #btn-contacto, .btn-contacto').forEach(button => {
      button.addEventListener('click', () => openWhatsApp(
        'Hola, quiero obtener información sobre Reporte Ciudadano.'
      ));
    });
  }

  function getReportForm() {
    return first('#report-form', '#form-reporte', '#formReporte', '#reporteForm',
      'form[data-report-form]', 'form[name="report-form"]');
  }
  function getModal() {
    return first('#report-modal', '#modal-reporte', '#modalReporte', '[data-report-modal]');
  }
  function openReportForm(category = '') {
    const form = getReportForm();
    const modal = getModal();
    if (form && category) {
      setField(form, ['categoria', 'category', 'tipoProblema', 'tipo-problema', 'tipo'], category);
    }
    if (modal) {
      modal.hidden = false;
      modal.classList.add('is-open', 'open', 'active');
      modal.setAttribute('aria-hidden', 'false');
      document.body.classList.add('modal-open');
    } else if (form) {
      scrollToElement(form);
    } else {
      showNotice('No se encontró el formulario. Revisa que exista #report-form o #form-reporte.', 'error');
    }
  }
  function closeReportForm() {
    const modal = getModal();
    if (modal) {
      modal.hidden = true;
      modal.classList.remove('is-open', 'open', 'active');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('modal-open');
    }
  }

  function setupModal() {
    $$('[data-close-modal], .modal-close, #close-report-modal, #cerrar-modal').forEach(button =>
      button.addEventListener('click', closeReportForm));
    const modal = getModal();
    if (modal) {
      modal.addEventListener('click', event => {
        if (event.target === modal) closeReportForm();
      });
      modal.setAttribute('aria-hidden', modal.hidden ? 'true' : 'false');
    }
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') closeReportForm();
    });
  }

  function setupCategoryCards() {
    const categoryCards = $$('[data-category], .category-card, .tarjeta-categoria');
    categoryCards.forEach(card => {
      card.addEventListener('click', () => {
        const category = card.dataset.category || clean($('h3, h2, .card-title', card)?.textContent);
        if (category) openReportForm(category);
      });
      if (!card.matches('button, a, input')) {
        card.setAttribute('tabindex', '0');
        card.setAttribute('role', 'button');
        card.addEventListener('keydown', event => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            card.click();
          }
        });
      }
    });
  }

  function setupLocation(form) {
    const button = formField(form, ['use-location', 'usarUbicacion', 'usar-ubicacion']) ||
      first('#use-location', '#usar-ubicacion', '[data-use-location]');
    if (!button || button.dataset.locationReady) return;
    button.dataset.locationReady = '1';
    button.addEventListener('click', () => {
      if (!navigator.geolocation) {
        showNotice('Este navegador no permite obtener la ubicación. Escríbela manualmente.', 'error');
        return;
      }
      button.disabled = true;
      button.textContent = 'Obteniendo ubicación…';
      navigator.geolocation.getCurrentPosition(position => {
        const { latitude, longitude } = position.coords;
        const locationField = formField(form, ['ubicacion', 'location', 'direccion', 'direccionProblema']);
        if (locationField) {
          locationField.value = `Coordenadas GPS: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
          locationField.dispatchEvent(new Event('input', { bubbles: true }));
        }
        button.disabled = false;
        button.textContent = 'Usar mi ubicación';
        showNotice('Ubicación obtenida. Puedes añadir una referencia o dirección.', 'success');
      }, () => {
        button.disabled = false;
        button.textContent = 'Usar mi ubicación';
        showNotice('No se pudo obtener la ubicación. Escribe la dirección manualmente.', 'error');
      }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
    });
  }

  function setupPhoto(form) {
    const photo = formField(form, ['fotografia', 'foto', 'photo', 'imagen', 'evidencia']);
    if (!photo) return;
    const display = first('#photo-name', '#nombre-foto', '[data-photo-name]');
    photo.addEventListener('change', () => {
      if (display) display.textContent = photo.files?.[0]?.name || 'Ninguna fotografía seleccionada';
      else if (photo.files?.[0]) showNotice(`Fotografía seleccionada: ${photo.files[0].name}`);
    });
  }

  function makeWhatsAppMessage(report) {
    return [
      'Nuevo reporte ciudadano.',
      '',
      `Código de seguimiento: ${report.codigo}`,
      `Nombre: ${report.nombre}`,
      `Tipo de problema: ${report.categoria}`,
      `Descripción: ${report.descripcion}`,
      `Ubicación: ${report.ubicacion}`,
      `Contacto: ${report.telefono || 'No indicado'}`,
      `Fecha de registro: ${dateText(report.fecha)}`
    ].join('\n');
  }

  function setupReportForm() {
    const form = getReportForm();
    if (!form || form.dataset.rcReady) return;
    form.dataset.rcReady = '1';
    const profile = getProfile();
    setField(form, ['nombre', 'nombreCiudadano', 'name'], profile.nombre);
    setField(form, ['telefono', 'contacto', 'phone'], profile.telefono);
    setupLocation(form);
    setupPhoto(form);

    form.addEventListener('submit', event => {
      event.preventDefault();
      if (typeof form.reportValidity === 'function' && !form.reportValidity()) return;

      const report = {
        codigo: '',
        nombre: val(form, ['nombre', 'nombreCiudadano', 'name']),
        telefono: val(form, ['telefono', 'contacto', 'phone']),
        categoria: val(form, ['categoria', 'category', 'tipoProblema', 'tipo-problema', 'tipo']),
        descripcion: val(form, ['descripcion', 'description', 'detalle']),
        ubicacion: val(form, ['ubicacion', 'location', 'direccion', 'direccionProblema']),
        fecha: todayISO(),
        estado: 'Recibido'
      };
      const missing = [];
      if (!report.nombre) missing.push('nombre');
      if (!report.categoria) missing.push('tipo de problema');
      if (!report.descripcion) missing.push('descripción');
      if (!report.ubicacion) missing.push('ubicación');
      if (missing.length) {
        showNotice('Completa los campos obligatorios: ' + missing.join(', ') + '.', 'error');
        const field = formField(form, ['nombre', 'categoria', 'descripcion', 'ubicacion']);
        if (field) field.focus();
        return;
      }

      const reports = getReports();
      const duplicate = reports.find(old =>
        slug(old.categoria) === slug(report.categoria) &&
        slug(old.ubicacion) === slug(report.ubicacion) &&
        (Date.now() - new Date(old.fecha).getTime()) < 7 * 24 * 60 * 60 * 1000
      );
      if (duplicate && !window.confirm(
        `Ya existe un reporte parecido (${duplicate.codigo}) para esta categoría y ubicación. ¿Deseas registrar otro de todos modos?`
      )) return;

      if (!window.confirm('¿Confirmas que los datos del reporte son correctos?')) return;
      report.codigo = makeCode(reports);
      reports.unshift(report);
      if (!saveJSON(STORAGE_REPORTS, reports)) return;

      const savedProfile = {
        nombre: report.nombre,
        telefono: report.telefono,
        correo: getProfile().correo
      };
      saveJSON(STORAGE_PROFILE, savedProfile);

      form.reset();
      setField(form, ['nombre', 'nombreCiudadano', 'name'], savedProfile.nombre);
      setField(form, ['telefono', 'contacto', 'phone'], savedProfile.telefono);
      closeReportForm();
      showConfirmation(report);

      // Se abre WhatsApp después de guardar. El usuario debe confirmar el envío.
      const message = makeWhatsAppMessage(report);
      const whatsappButton = first('#send-whatsapp', '#enviar-whatsapp', '[data-send-whatsapp]');
      if (whatsappButton) {
        whatsappButton.onclick = () => openWhatsApp(message);
      } else {
        const proceed = window.confirm(
          `Reporte guardado con código ${report.codigo}.\n\n¿Quieres abrir WhatsApp para preparar el mensaje? Tendrás que pulsar Enviar dentro de WhatsApp.`
        );
        if (proceed) openWhatsApp(message);
      }
    });
  }

  function showConfirmation(report) {
    let panel = first('#report-confirmation', '#confirmacion-reporte', '[data-report-confirmation]');
    if (!panel) {
      panel = document.createElement('section');
      panel.id = 'report-confirmation';
      panel.setAttribute('aria-live', 'polite');
      panel.style.cssText = 'margin:20px auto;padding:22px;max-width:720px;border:1px solid #b7e4cc;border-radius:16px;background:#f0fbf5;color:#174b35';
      const anchor = first('#seguimiento', '#tracking', 'main') || document.body;
      anchor.prepend(panel);
    }
    panel.hidden = false;
    panel.innerHTML = `<h3>¡Reporte guardado correctamente!</h3>
      <p>Tu código de seguimiento es:</p>
      <p style="font-size:1.4rem;font-weight:800;letter-spacing:.04em">${escapeHTML(report.codigo)}</p>
      <p>Estado inicial: <strong>Recibido</strong>. Los datos se guardaron en este navegador.</p>
      <p>El estado es local y demostrativo; no confirma que una institución haya recibido el reporte.</p>
      <button type="button" id="copy-report-code" style="padding:10px 14px;border-radius:9px;cursor:pointer">Copiar código</button>
      <button type="button" id="send-whatsapp" style="padding:10px 14px;border-radius:9px;cursor:pointer;margin-left:8px">Enviar por WhatsApp</button>`;
    $('#copy-report-code', panel).addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(report.codigo);
        showNotice('Código copiado.', 'success');
      } catch (_) {
        window.prompt('Copia tu código de seguimiento:', report.codigo);
      }
    });
    $('#send-whatsapp', panel).addEventListener('click', () => openWhatsApp(makeWhatsAppMessage(report)));
    scrollToElement(panel);
  }

  function setupTracking() {
    const form = first('#tracking-form', '#form-seguimiento', '#formSeguimiento', 'form[data-tracking-form]');
    const codeInput = first('#tracking-code', '#codigo-seguimiento', '#codigoSeguimiento', 'input[name="codigoSeguimiento"]', 'input[name="codigo"]');
    const result = first('#tracking-result', '#resultado-seguimiento', '#resultadoSeguimiento', '[data-tracking-result]');
    const submit = form || first('#consultar-reporte', '#btn-consultar', '[data-track-report]');
    if (!submit || submit.dataset.rcReady) return;
    submit.dataset.rcReady = '1';

    const search = event => {
      if (event) event.preventDefault();
      const code = clean(codeInput?.value).toUpperCase();
      if (!code) {
        showNotice('Introduce el código de seguimiento.', 'error');
        codeInput?.focus();
        return;
      }
      const report = getReports().find(item => String(item.codigo).toUpperCase() === code);
      if (!result) {
        showNotice(report ? `Estado de ${report.codigo}: ${report.estado}` : 'No se encontró ese código.', report ? 'success' : 'error');
        return;
      }
      result.hidden = false;
      if (!report) {
        result.innerHTML = `<div class="tracking-empty"><h3>No encontramos ese reporte</h3><p>Comprueba el código o registra un nuevo reporte. Los reportes solo se encuentran en el navegador donde fueron guardados.</p><button type="button" data-open-report>Crear un reporte</button></div>`;
        $('[data-open-report]', result)?.addEventListener('click', () => openReportForm());
        return;
      }
      const current = Math.max(0, STATUS.indexOf(report.estado));
      const progress = ((current + 1) / STATUS.length) * 100;
      result.innerHTML = `<article class="tracking-card">
        <h3>Reporte ${escapeHTML(report.codigo)}</h3>
        <p><strong>Categoría:</strong> ${escapeHTML(report.categoria)}</p>
        <p><strong>Ubicación:</strong> ${escapeHTML(report.ubicacion)}</p>
        <p><strong>Fecha de registro:</strong> ${escapeHTML(dateText(report.fecha))}</p>
        <p><strong>Estado actual:</strong> <span class="status status-${current}">${escapeHTML(report.estado)}</span></p>
        <div class="tracking-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progress}" style="height:10px;background:#e5edf3;border-radius:10px;overflow:hidden"><div style="width:${progress}%;height:100%;background:#27865a;transition:width .3s"></div></div>
        <ol class="tracking-steps">${STATUS.map((status, i) => `<li class="${i <= current ? 'completed' : ''}">${escapeHTML(status)}</li>`).join('')}</ol>
        <p class="tracking-note">Este seguimiento es local y demostrativo. No hay conexión institucional ni actualizaciones oficiales.</p>
      </article>`;
    };
    if (form) form.addEventListener('submit', search);
    else submit.addEventListener('click', search);
  }

  function setupProfile() {
    const form = first('#profile-form', '#form-perfil', '#formPerfil', 'form[data-profile-form]');
    const openButton = first('#open-profile', '#btn-perfil', '[data-open-profile]');
    const modal = first('#profile-modal', '#modal-perfil', '[data-profile-modal]');
    if (openButton && modal) openButton.addEventListener('click', () => {
      modal.hidden = false;
      modal.classList.add('is-open', 'open');
      const profile = getProfile();
      if (form) {
        setField(form, ['nombre', 'name'], profile.nombre);
        setField(form, ['telefono', 'phone'], profile.telefono);
        setField(form, ['correo', 'email'], profile.correo);
      }
    });
    if (!form || form.dataset.rcReady) return;
    form.dataset.rcReady = '1';
    const profile = getProfile();
    setField(form, ['nombre', 'name'], profile.nombre);
    setField(form, ['telefono', 'phone'], profile.telefono);
    setField(form, ['correo', 'email'], profile.correo);
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = {
        nombre: val(form, ['nombre', 'name']),
        telefono: val(form, ['telefono', 'phone']),
        correo: val(form, ['correo', 'email'])
      };
      if (!data.nombre) {
        showNotice('El nombre es obligatorio.', 'error');
        return;
      }
      if (!saveJSON(STORAGE_PROFILE, data)) return;
      const reportForm = getReportForm();
      if (reportForm) {
        setField(reportForm, ['nombre', 'nombreCiudadano', 'name'], data.nombre);
        setField(reportForm, ['telefono', 'contacto', 'phone'], data.telefono);
      }
      if (modal) { modal.hidden = true; modal.classList.remove('is-open', 'open'); }
      showNotice('Perfil guardado solo en este navegador.', 'success');
    });
  }

  const IMPROVEMENT_CONTENT = {
    'reporta lo que ves': ['Reporta lo que ves', 'Describe el problema con claridad e indica una ubicación que ayude a encontrarlo.'],
    'aporta evidencia': ['Aporta evidencia', 'Si tienes una fotografía, puedes seleccionarla como referencia. La foto no se adjunta automáticamente a WhatsApp.'],
    'participa en comunidad': ['Participa en comunidad', 'Compartir información clara ayuda a que otras personas comprendan el problema y eviten reportes confusos.'],
    'haz seguimiento': ['Haz seguimiento', 'Guarda tu código y úsalo para consultar el reporte en el mismo navegador donde lo registraste.']
  };
  function setupImprovementCards() {
    const cards = $$('[data-improvement], .improvement-card, .accion-card');
    const panel = first('#improvement-panel', '#panel-mejorar', '[data-improvement-panel]');
    cards.forEach(card => card.addEventListener('click', () => {
      const key = slug(card.dataset.improvement || $('h3,h2,.card-title', card)?.textContent);
      const content = IMPROVEMENT_CONTENT[key];
      if (!content || !panel) return;
      panel.hidden = false;
      panel.innerHTML = `<div class="improvement-detail"><h3>${escapeHTML(content[0])}</h3><p>${escapeHTML(content[1])}</p><button type="button" data-open-report>Crear un reporte</button></div>`;
      $('[data-open-report]', panel).addEventListener('click', () => openReportForm());
      cards.forEach(item => item.classList.toggle('selected', item === card));
    }));
  }

  function setupDynamicStatusDemo() {
    // No se ofrece un control público para cambiar estados: no hay servidor institucional.
    // Los estados se consultan tal como están guardados, sin inventar avances.
  }

  function setupProfilePrivacy() {
    $$('[data-clear-local-data], #borrar-datos-locales').forEach(button => button.addEventListener('click', () => {
      if (!confirm('¿Eliminar todos los reportes y el perfil guardados en este navegador? Esta acción no se puede deshacer.')) return;
      localStorage.removeItem(STORAGE_REPORTS);
      localStorage.removeItem(STORAGE_PROFILE);
      showNotice('Datos locales eliminados.', 'success');
    }));
  }

  function init() {
    setupNavigation();
    setupModal();
    setupCategoryCards();
    setupReportForm();
    setupTracking();
    setupProfile();
    setupImprovementCards();
    setupProfilePrivacy();
    setupDynamicStatusDemo();

    // Enlaces de contacto existentes: corregir el destino para que use el número indicado.
    $$('a[href*="wa.me"]').forEach(link => {
      if (link.matches('[data-contact-whatsapp], #btn-contacto, .btn-contacto')) {
        link.href = whatsappURL('Hola, quiero obtener información sobre Reporte Ciudadano.');
      }
    });
    console.info('Reporte Ciudadano: JavaScript inicializado.');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }

  // Funciones disponibles para botones inline antiguos, si el HTML ya los utiliza.
  window.abrirFormularioReporte = openReportForm;
  window.cerrarFormularioReporte = closeReportForm;
})();
